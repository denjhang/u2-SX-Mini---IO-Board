u2-SX Logo v1.0
===============
This specific logo was requested by Denjhang on 2023.09.30 for its u2-SX project, a 2nd Gen MSX++ compatible machine.


______________
KdL 2023.10.02
